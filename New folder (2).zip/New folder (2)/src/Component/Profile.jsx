import React from "react";
import "./Profile";

const Profile = () => {
  return (
    <div className="profile-container">
      <div className="profile-card">

        {/* Profile Image */}
        <img 
          src="Gemini_Generated_Image_70yj3n70yj3n70yj.png" 
          alt="Sachin Profile" 
          className="profile-img"
        />

        {/* User Info */}
        <h1 className="name">Sachin Kumar</h1>
        <h3 className="tagline">Web Developer | React | Node.js | MongoDB</h3>

        <p className="bio">
          I am a passionate web developer from India, focused on building modern, 
          responsive, and user-friendly web applications. I love coding, learning, 
          and helping others grow in tech. 🚀
        </p>

        {/* Skills Section */}
        <h2 className="section-title">Skills</h2>
        <div className="skills">
          <span>HTML</span>
          <span>CSS</span>
          <span>JavaScript</span>
          <span>React.js</span>
          <span>Node.js</span>
          <span>MongoDB</span>
        </div>

        {/* Buttons */}
        <div className="buttons">
          <a href="https://wa.me/917323966221" target="_blank" className="btn whatsapp">WhatsApp</a>
          <a href="tel:+917323966221" className="btn call">Call Me</a>
        </div>
      </div>
    </div>
  );
};

export default Profile;
