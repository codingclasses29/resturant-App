import React from "react";
import "./Home";

const Home = () => {
  return (
    <div className="site">
      {/* Header */}
      <header className="header">
        <div className="brand">
          <div className="logo"></div>
          <div>
            <div className="brand-title">Sachin.Net</div>
            <div className="sub">Simple • Fast • Clean</div>
          </div>
        </div>

        {/* Nav */}
        <nav>
          <a href="#">Home</a>
          <a href="#">About</a>
          <a href="#">Contact</a>
        </nav>
      </header>

      {/* Hero Section */}
      <section className="hero">
        <div className="left">
          <h1>Welcome to Sachin.Net</h1>
          <p>
            This React homepage layout is built clean and centered for Sachin.Net.
            You can now customize and connect backend or more pages.
          </p>
          <button className="cta">Get Started 🚀</button>
        </div>

        <div className="right">
          <img
            src="Gemini_Generated_Image_70yj3n70yj3n70yj.png"
            alt="Demo"
          />
        </div>
      </section>

      {/* Info Boxes */}
      <div className="cards">
        <div className="card">
          <h3>About</h3>
          <p>
            Replace this sample text and build your personal or portfolio website
            using React.
          </p>
        </div>

        <div className="card">
          <h3>Services</h3>
          <p>Website Design, Hosting setup, Portfolio & Business Sites.</p>
        </div>

        <div className="card">
          <h3>Contact</h3>
          <p>Email: you@sachin.net (replace with your email later)</p>
        </div>
      </div>

      {/* Footer */}
      <footer className="footer">© 2025 Sachin.Net | All Rights Reserved</footer>
    </div>
  );
};

export default Home;
