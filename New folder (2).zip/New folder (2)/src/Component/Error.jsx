import React from "react";
import "./Error";

const Error = () => {
  return (
    <div className="notfound-container">
      <h1>404</h1>
      <h2>Oops! Page Not Found</h2>
      <p>The page you are looking for doesn't exist.</p>

      <a href="/" className="home-btn">
        Go Back Home
      </a>
    </div>
  );
};

export default Error;
