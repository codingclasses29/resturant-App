import React from "react";
import "./About";

const About = () => {
  return (
    <div className="about-container">
      <div className="about-content">
        <h1>About Sachin.Net</h1>
        <p>
          Welcome to <strong>Sachin.Net</strong> — a platform designed to share
          knowledge, tutorials, and coding resources for beginners and
          developers. Our mission is to make learning easy, practical, and fun.
        </p>

        <p>
          Whether you're exploring web development, React, JavaScript, or
          backend technologies — Sachin.Net provides real project examples,
          guides, and helpful step-by-step learning content.
        </p>

        <h2>Our Goals</h2>
        <ul>
          <li>✔ Provide quality coding tutorials</li>
          <li>✔ Help beginners learn real-world skills</li>
          <li>✔ Share projects with source code</li>
          <li>✔ Build a strong learning community</li>
        </ul>

        <p className="footer-text">
          Thanks for visiting — Stay connected and keep learning! 🚀
        </p>
      </div>
    </div>
  );
};

export default About;
