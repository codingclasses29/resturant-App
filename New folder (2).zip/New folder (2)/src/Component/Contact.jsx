import React, { useState } from "react";
import "./Contact";

const Contact = () => {
  const phone = "7323966221";           // raw number (local)
  const countryCode = "91";             // change if not India
  const intlPhone = `${countryCode}${phone}`; // for wa.me and tel:+ use
  const whatsappLink = `https://wa.me/${intlPhone}`;
  const telLink = `tel:+${intlPhone}`;
  const email = "youremail@example.com"; // replace with your email
  const mailtoLink = `mailto:${email}`;

  const [form, setForm] = useState({ name: "", email: "", message: "" });
  const [sent, setSent] = useState(false);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    // For demo: just show confirmation. Replace with API call if needed.
    console.log("Contact form submitted:", form);
    setSent(true);
    setForm({ name: "", email: "", message: "" });
    setTimeout(() => setSent(false), 3500);
  };

  return (
    <div className="contact-page">
      <div className="contact-card">
        <h1>Contact Sachin.Net</h1>
        <p className="lead">
          Have a question or want to collaborate? Reach out by WhatsApp, phone or
          send a message below.
        </p>

        <div className="contact-actions">
          <a
            className="btn whatsapp"
            href={whatsappLink}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Chat on WhatsApp"
          >
            Chat on WhatsApp
            <span className="small">({`+${intlPhone}`})</span>
          </a>

          <a className="btn phone" href={telLink} aria-label="Call phone">
            Call: {phone}
          </a>

          <a className="btn email" href={mailtoLink} aria-label="Send email">
            Email: {email}
          </a>
        </div>

        <form className="contact-form" onSubmit={handleSubmit}>
          <label>
            Name
            <input
              name="name"
              value={form.name}
              onChange={handleChange}
              required
              placeholder="Your name"
            />
          </label>

          <label>
            Email
            <input
              name="email"
              type="email"
              value={form.email}
              onChange={handleChange}
              required
              placeholder="you@example.com"
            />
          </label>

          <label>
            Message
            <textarea
              name="message"
              value={form.message}
              onChange={handleChange}
              required
              placeholder="Tell me about your project..."
            />
          </label>

          <button type="submit" className="btn submit">
            Send Message
          </button>

          {sent && <div className="sent-msg">Message sent — thank you!</div>}
        </form>
      </div>
    </div>
  );
};

export default Contact;
