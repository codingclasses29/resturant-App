import { BrowserRouter, Routes, Route } from "react-router-dom";
import "./App.css";
import Navbhar from "./Component/Navbhar";
import Footer from "./Component/Footer";
import Home from "./Component/Home";
import About from "./Component/About";
import Contact from "./Component/Contact";
import Error from "./Component/Error";
import Profile from "./Component/Profile";


function App() {
  return (
    <>
      <BrowserRouter>
        <div>
          <Navbhar></Navbhar>
          <hr></hr>
          {/* Add Child Pages*/}

         <Routes>
          <Route path="/" element={<Home></Home>}></Route>
          <Route path="/About" element={<About></About>}></Route>
          <Route path="/Contact" element={<Contact></Contact>}></Route>
          <Route path="/Error" element={<Error></Error>}></Route>
          <Route path="/Profile" element={<Profile></Profile>}></Route>
          



         </Routes>

          <hr></hr>
          <Footer></Footer>
        </div>
      </BrowserRouter>
    </>
  );
}

export default App;
